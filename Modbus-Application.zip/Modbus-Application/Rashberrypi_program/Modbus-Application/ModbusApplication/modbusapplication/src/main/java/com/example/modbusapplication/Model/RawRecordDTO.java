package com.example.modbusapplication.Model;

public class RawRecordDTO {
    private String encByteString;

    public String getEncByteString() {
        return encByteString;
    }

    public RawRecordDTO(String encByteString) {
        this.encByteString = encByteString;
    }

    public void setEncByteString(String encByteString) {
        this.encByteString = encByteString;
    }

    
}

